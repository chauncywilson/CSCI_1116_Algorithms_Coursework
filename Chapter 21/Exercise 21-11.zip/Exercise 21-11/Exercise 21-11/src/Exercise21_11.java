import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise21_11 extends Application {
  private Map<String, Integer>[] mapForBoy = new HashMap[10];
  private Map<String, Integer>[] mapForGirl = new HashMap[10];

  private String[] urls = {"http://liveexample.pearsoncmg.com/data/babynamesranking2001.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2002.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2003.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2004.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2005.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2006.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2007.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2008.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2009.txt",
          "http://liveexample.pearsoncmg.com/data/babynamesranking2010.txt"
  };
  
  private Button btFindRanking = new Button("Find Ranking");
  private ComboBox<Integer> cboYear = new ComboBox<>();
  private ComboBox<String> cboGender = new ComboBox<>();
  private TextField tfName = new TextField();
  private Label lblResult = new Label();
  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    GridPane gridPane = new GridPane();
    gridPane.add(new Label("Select a year:"), 0, 0);
    gridPane.add(new Label("Boy or girl?"), 0, 1);
    gridPane.add(new Label("Enter a name:"), 0, 2);
    gridPane.add(cboYear, 1, 0);
    gridPane.add(cboGender, 1, 1);
    gridPane.add(tfName, 1, 2);
    gridPane.add(btFindRanking, 1, 3);

    btFindRanking.setOnAction(event -> {
      int year = cboYear.getValue();
      int arrayYear = year - 2001;
      String gender = cboGender.getValue();
      if (gender.equals("Male")) {
        if (mapForBoy[arrayYear].get(tfName.getText()) != -1) {
          int rank = mapForBoy[arrayYear].get(tfName.getText());
          lblResult.setText("Boy named " + tfName.getText() + " is ranked #" + rank + " in year " + year);
        } else {
          lblResult.setText("Boy named " + tfName.getText() + " is not ranked in year " + year);
        }
      } else {
        if (mapForGirl[arrayYear].get(tfName.getText()) != -1) {
          int rank = mapForGirl[arrayYear].get(tfName.getText());
          lblResult.setText("Girl named " + tfName.getText() + " is ranked #" + rank + " in year " + year);
        } else {
          lblResult.setText("Girl named " + tfName.getText() + " is not ranked in year " + year);
        }
      }
    });

    gridPane.setAlignment(Pos.CENTER);
    gridPane.setHgap(5);
    gridPane.setVgap(5);

    setArrays();
  
    BorderPane borderPane = new BorderPane();
    borderPane.setCenter(gridPane);
    borderPane.setBottom(lblResult);
    BorderPane.setAlignment(lblResult, Pos.CENTER);

    // Create a scene and place it in the stage
    Scene scene = new Scene(borderPane, 370, 160);
    primaryStage.setTitle("Exercise21_11"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    for (int year = 2001; year <= 2010; year++) {
      cboYear.getItems().add(year);
    }
    cboYear.setValue(2001);
        
    cboGender.getItems().addAll("Male", "Female");
    cboGender.setValue("Male");
    
  }

  public void setArrays() {
    try {
      for (int i = 0; i < 10; i++) {
        URL url = new URL(urls[i]);
        int count = 0;
        Scanner input = new Scanner(url.openStream());

        mapForBoy[i] = new HashMap<>();
        mapForGirl[i] = new HashMap<>();

        while (input.hasNext()) {
          int rank = input.nextInt();
          String boyName = input.next();
          input.next();
          String girlName = input.next();
          input.next();

          mapForBoy[i].put(boyName, rank);
          mapForGirl[i].put(girlName, rank);
          count++;
        }
        System.out.println("The file size is " + count + " loops");
      }
    } catch(java.net.MalformedURLException ex) {
      System.out.println("Invalid URL");
    }
    catch(java.io.IOException ex) {
        System.out.println("I/0 Errors: no such file");
    }
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}

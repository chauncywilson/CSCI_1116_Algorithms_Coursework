/*
Chauncy Wilson
Algorithms and Data Structures
1/11/23
Implement GenericQueue using inheritance
 */

public class Exercise24_5 {
    public static void main(String[] args) {

        GenericQueue genericQueue = new GenericQueue();

        System.out.println("Before enqueue: " + genericQueue);
        System.out.println("Enqueue: 5, 10, 15, 20");
        int [] enqueue = {5, 10, 15, 20};
        genericQueue.enqueue(enqueue);
        System.out.println("After enqueue: " + genericQueue);

        System.out.println();

        System.out.println("Before dequeue: " + genericQueue);
        System.out.println("Dequeue: 5, 6, 10, 12");
        int [] dequeue = {5, 6, 10, 12};
        genericQueue.dequeue(dequeue);
        System.out.println("After Dequeue: " + genericQueue);
    }
}

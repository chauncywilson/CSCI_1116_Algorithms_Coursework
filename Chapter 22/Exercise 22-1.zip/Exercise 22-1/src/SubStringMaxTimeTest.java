import java.util.Calendar;
import java.util.GregorianCalendar;

//Time Complexity estimate O()

public class SubStringMaxTimeTest {
    public static void main(String[] args) {


        String line = "zzzzzzzzzzzzzzzzzzzzzzzzzzzabcdefghijklmnopqrstuvwxyzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz";

        SubStringMax subStringMax = new SubStringMax();

        Calendar calendar = new GregorianCalendar();

        long startTime = calendar.getTimeInMillis();
        subStringMax.findSubString(line);
        long endTime = calendar.getTimeInMillis();

        long finalTime = endTime - startTime;

        System.out.println("Time to complete: " + finalTime);
    }
}

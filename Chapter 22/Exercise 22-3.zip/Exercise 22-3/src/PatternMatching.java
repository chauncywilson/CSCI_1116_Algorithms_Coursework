/*
Chauncy Wilson, Algorithms and Data Structures

1/25/23, Pattern matching in strings
 */

import java.util.Scanner;

public class PatternMatching {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a string s1: ");
        String s1 = input.nextLine();

        System.out.print("\nEnter a string s2: ");
        String s2 = input.nextLine();

        if (getMatch(s1, s2) >= 0) {
            System.out.println("Matched at index " + getMatch(s1, s2));
        } else {
            System.out.println("No match found");
        }
    }

    public static int getMatch(String s1, String s2) {
        int i = 0;
        for (int j = 0; i < s1.length(); ) {
            char[] chars = s2.toCharArray();
            if (chars[j] == s1.charAt(i + j)) {
                j++;
                if (chars.length - 1 == j) {
                    return i;
                }
            } else {
                j = 0;
                i++;
            }
        }
        return -1;
    }
}

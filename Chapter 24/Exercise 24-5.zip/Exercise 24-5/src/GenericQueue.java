import java.util.LinkedList;

public class GenericQueue extends LinkedList {
    public static void main(String[] args) {

    }

    public boolean enqueue(int[] list) {
        for (int i = 0; i < list.length; i++) {
            add(list[i]);
        }
        return true;
    }

    public boolean dequeue(int[] list) {
        if (list.length != 0) {
            for (int i = 0; i < list.length; i++) {
                if (contains(list[i])) {
                    remove(indexOf(list[i]));
                }
            }
            return true;
        } else {
            return false;
        }
    }
}

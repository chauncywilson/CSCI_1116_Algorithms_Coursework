import java.util.Scanner;

/*
Chauncy Wilson, Algorithms and Data Structures

Find the max subString and clock the time, 1/24/23
 */

public class SubStringMax {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        SubStringMax subStringMax = new SubStringMax();

        System.out.print("Enter a string: ");
        String line = input.nextLine();

        System.out.print("\nMaximum consecutive substring is " + subStringMax.findSubString(line));
    }

    public String findSubString(String line) {
        // a = 79, z = 122 (decimal code)
        int lengthCount;
        int currentLongest = 0;
        int maxLengthCount = 0;
        for (int i = 0; i < line.length(); i++) {
            lengthCount = 1;
            for (int j = i + 1; j < line.length(); j++) {
                char next = line.charAt(j);
                char previous = line.charAt(j - 1);

                if (next > previous) {
                    lengthCount++;
                } else {
                    if (maxLengthCount < lengthCount) {
                        currentLongest = i;
                        maxLengthCount = lengthCount;
                    }
                    break;
                }
            }
        }
        return line.substring(currentLongest, currentLongest + maxLengthCount);
    }
}
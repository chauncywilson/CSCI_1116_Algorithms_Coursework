import java.util.*;

public class CountOccurrenceOfWords {
	public static void main(String[] args) {
		// Set text in a string
		String text = "Good morning. Have a good class. " +
				"Have a good visit. Have fun!";

		// Create a TreeMap to hold words as key and count as value
		Map<String, Integer> map = new HashMap<>();

		ArrayList<WordOccurrence> organizedWords = new ArrayList<>();

		String[] words = text.split("[\\s+\\p{P}]");
		for (int i = 0; i < words.length; i++) {
			String key = words[i].toLowerCase();

			if (key.length() > 0) {
				if (!map.containsKey(key)) {
					map.put(key, 1);

					WordOccurrence wordOccurrence = new WordOccurrence(key, 1);
					organizedWords.add(wordOccurrence);

				} else {
					int value = map.get(key);
					value++;
					map.put(key, value);
				}
			}
		}

		//set the count for the organizedWords objects
		for (int i = 0; i < map.size(); i++) {
			organizedWords.get(i).setCount(map.get(organizedWords.get(i).getWord()));
		}

		//organize the group by smallest key values
		for (int i = 0; i < organizedWords.size() - 1; i++) {
			for (int j = i + 1; j < organizedWords.size(); j++) {
				
				WordOccurrence currentMin = organizedWords.get(i);
				int contenderCount = organizedWords.get(j).getCount();
				WordOccurrence contender = organizedWords.get(j);

				if (currentMin.compareTo(contenderCount) > 0) {
					organizedWords.remove(contender);
					organizedWords.add(contender);

				} else if (currentMin.compareTo(contenderCount) < 0){
					organizedWords.remove(currentMin);
					organizedWords.add(currentMin);
				}
			}
		}

		// Display key and value for each entry
		for (WordOccurrence organizedWord : organizedWords) {
			System.out.println(organizedWord.getWord() + "\t" + organizedWord.getCount());
		}
	}
}
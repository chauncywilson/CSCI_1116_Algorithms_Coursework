/*
Chauncy Wilson
Algorithms and Data Structures
1/12/23
Organize by word occurrence
 */

//Tasks: Fix the null number issue, fix the sort function, and figure out how to properly use the compareTo method

public class WordOccurrence implements Comparable {

    String word;
    int count;

    public WordOccurrence(String word, int count) {
        setWord(word);
        setCount(count);
    }

    public int compareTo(int count1) {
        if (count > count1) {
            return -1;
        }
        else if (count == count1) {
            return 0;
        }
        else return 1;
    }

    public String getWord() {
        return word;
    }

    public int getCount() {
        return count;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }


}
